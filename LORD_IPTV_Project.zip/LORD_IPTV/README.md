# 👑 LORD IPTV — دليل البناء السحابي الكامل

## 📋 المحتويات
- مشروع Android Studio كامل
- مشغل HLS/M3U8 باستخدام ExoPlayer (Media3)
- مراقبة Ping للسيرفر بشكل لحظي
- دعم Android TV + Remote Control
- Splash Screen + شعار LORD

---

## 🚀 الطريقة: بناء APK بدون تثبيت أي شيء (GitHub Actions)

### الخطوة 1 — إنشاء حساب GitHub (مجاني)
1. افتح [github.com](https://github.com) وأنشئ حساباً مجانياً
2. اضغط **New Repository**
3. سمّه: `lord-iptv`
4. اختر **Private** أو **Public**
5. اضغط **Create Repository**

---

### الخطوة 2 — رفع المشروع
**الطريقة السهلة (بدون Git):**
1. في صفحة الـ Repository اضغط **uploading an existing file**
2. اسحب مجلد المشروع كاملاً وأفلته
3. اضغط **Commit changes**

**أو باستخدام Git (أسرع):**
```bash
cd LORD_IPTV
git init
git add .
git commit -m "Initial LORD IPTV project"
git branch -M main
git remote add origin https://github.com/اسمك/lord-iptv.git
git push -u origin main
```

---

### الخطوة 3 — البناء التلقائي
1. بعد رفع الملفات، اذهب إلى تبويب **Actions** في الـ Repository
2. ستجد Workflow اسمه **Build LORD IPTV APK**
3. اضغط عليه ثم اضغط **Run workflow** ← **Run workflow**
4. ⏳ انتظر 5-10 دقائق للبناء الأول (ثم يصبح أسرع بسبب الـ Cache)

---

### الخطوة 4 — تحميل الـ APK ✅
1. بعد انتهاء البناء (علامة ✅ خضراء)
2. اضغط على اسم الـ Run
3. ستجد في أسفل الصفحة قسم **Artifacts**:
   - **LORD-IPTV-Release** ← النسخة النهائية المضغوطة (أقل من 30MB)
   - **LORD-IPTV-Debug** ← نسخة الاختبار
4. اضغط **Download** وستحصل على ملف ZIP يحتوي APK

---

## 📱 تثبيت APK على الجهاز

### على الهاتف/التابلت:
1. نقل الـ APK للجهاز عبر USB أو واتساب
2. اذهب إلى **الإعدادات ← الأمان ← السماح بمصادر غير معروفة**
3. افتح الملف وثبّت

### على Android TV / Fire TV:
1. ثبّت تطبيق **Downloader** من المتجر
2. أدخل رابط الـ APK أو استخدم **ADB Sideload**

---

## 📁 هيكل المشروع

```
LORD_IPTV/
├── .github/workflows/build.yml     ← GitHub Actions (البناء السحابي)
├── app/
│   ├── src/main/
│   │   ├── java/com/lord/iptv/
│   │   │   ├── data/
│   │   │   │   └── ChannelRepository.kt   ← قائمة القنوات
│   │   │   ├── ui/
│   │   │   │   ├── SplashActivity.kt      ← شاشة البداية
│   │   │   │   ├── MainActivity.kt        ← قائمة القنوات + Ping
│   │   │   │   └── ChannelAdapter.kt      ← عناصر القنوات
│   │   │   ├── player/
│   │   │   │   └── PlayerActivity.kt      ← المشغل الاحترافي
│   │   │   └── utils/
│   │   │       └── ServerMonitor.kt       ← مراقبة السيرفر
│   │   └── res/
│   │       ├── layout/                    ← واجهات XML
│   │       ├── drawable/                  ← أيقونات
│   │       └── values/                    ← ألوان + نصوص + ثيمات
│   └── build.gradle                       ← إعدادات الـ App
└── build.gradle                           ← إعدادات المشروع
```

---

## ⚙️ مميزات التطبيق
| الميزة | التفاصيل |
|--------|----------|
| 📺 المشغل | ExoPlayer (Media3) - يدعم HLS/M3U8/TS/MP4 |
| 🔄 إعادة اتصال | تلقائية حتى 10 محاولات |
| 📡 Ping | يُحدَّث كل 5 ثوانٍ |
| 🎮 TV Remote | دعم كامل D-pad + مفاتيح الوسائط |
| 📱 الشاشات | موبايل + تابلت + Android TV + شاشات ذكية |
| ⚡ الحجم | هدف أقل من 30MB (Release مضغوط) |
| 📅 Android | يدعم API 21+ (Android 5.0 فما فوق) |

---

## 🖼️ إضافة الشعار

ضع صورة الشعار (PNG) في المسارات التالية باستخدام Android Studio:
- `app/src/main/res/mipmap-hdpi/ic_launcher.png` (72×72)
- `app/src/main/res/mipmap-xhdpi/ic_launcher.png` (96×96)
- `app/src/main/res/mipmap-xxhdpi/ic_launcher.png` (144×144)
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png` (192×192)

**أو** في Android Studio: كليك يمين على `res` ← **New** ← **Image Asset** ← استورد الصورة

---

## ❓ مشاكل شائعة وحلولها

| المشكلة | الحل |
|---------|------|
| Build failed: SDK not found | تأكد من رفع كل ملفات المشروع |
| APK لا يُثبَّت | فعّل "مصادر غير معروفة" في الإعدادات |
| القنوات لا تشتغل | تأكد من اتصال الإنترنت وعمل السيرفر |
| شاشة سوداء في TV | تأكد من دعم جهازك لـ HLS |

---

*LORD IPTV — اللورد لخدمات الإنترنت*

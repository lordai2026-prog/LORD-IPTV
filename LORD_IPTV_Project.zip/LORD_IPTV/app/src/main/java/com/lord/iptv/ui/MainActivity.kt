package com.lord.iptv.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.lord.iptv.data.Channel
import com.lord.iptv.data.ChannelRepository
import com.lord.iptv.databinding.ActivityMainBinding
import com.lord.iptv.player.PlayerActivity
import com.lord.iptv.utils.ServerMonitor
import com.lord.iptv.utils.ServerStatus

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ChannelAdapter
    private var monitorJob: kotlinx.coroutines.Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        startServerMonitor()
    }

    private fun setupRecyclerView() {
        val channels = ChannelRepository.getChannels()
        adapter = ChannelAdapter(channels) { channel ->
            openPlayer(channel)
        }
        binding.rvChannels.layoutManager = LinearLayoutManager(this)
        binding.rvChannels.adapter = adapter
        binding.rvChannels.setHasFixedSize(true)
    }

    private fun openPlayer(channel: Channel) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_URL,  channel.url)
            putExtra(PlayerActivity.EXTRA_NAME, channel.name)
        }
        startActivity(intent)
    }

    private fun startServerMonitor() {
        monitorJob = ServerMonitor.startMonitoring(
            host       = ChannelRepository.serverHost,
            port       = ChannelRepository.serverPort,
            intervalMs = 5000L,
            scope      = lifecycleScope
        ) { result ->
            val pingText = if (result.pingMs >= 0) "${result.pingMs} ms" else "---"
            binding.tvPing.text = "Ping: $pingText"

            val (statusText, color) = when (result.status) {
                ServerStatus.CONNECTED    -> Pair("● متصل",       0xFF4CAF50.toInt())
                ServerStatus.WEAK         -> Pair("● ضعيف",       0xFFFF9800.toInt())
                ServerStatus.DISCONNECTED -> Pair("● غير متصل",   0xFFF44336.toInt())
            }
            binding.tvServerStatus.text  = statusText
            binding.tvServerStatus.setTextColor(color)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        monitorJob?.cancel()
    }
}

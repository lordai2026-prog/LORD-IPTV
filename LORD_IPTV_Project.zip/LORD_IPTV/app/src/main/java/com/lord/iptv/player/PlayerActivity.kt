package com.lord.iptv.player

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import com.lord.iptv.databinding.ActivityPlayerBinding
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL  = "extra_url"
        const val EXTRA_NAME = "extra_name"
    }

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private var streamUrl: String = ""
    private var streamName: String = ""

    private var retryCount    = 0
    private val maxRetries    = 10
    private val retryDelayMs  = 3000L
    private val retryHandler  = Handler(Looper.getMainLooper())

    // OkHttp client for better streaming performance
    private val okHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        streamUrl  = intent.getStringExtra(EXTRA_URL)  ?: ""
        streamName = intent.getStringExtra(EXTRA_NAME) ?: "LORD IPTV"

        binding.tvChannelName.text = streamName
        binding.btnBack.setOnClickListener { finish() }

        initPlayer()
    }

    private fun initPlayer() {
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            binding.playerView.player = exo

            val dataSourceFactory = OkHttpDataSource.Factory(okHttpClient)
                .setDefaultRequestProperties(
                    mapOf("User-Agent" to "LORD-IPTV/1.0 (Android)")
                )

            val mediaItem    = MediaItem.fromUri(streamUrl)
            val mediaSource  = HlsMediaSource.Factory(dataSourceFactory)
                .createMediaSource(mediaItem)

            exo.setMediaSource(mediaSource)
            exo.prepare()
            exo.playWhenReady = true

            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        Player.STATE_BUFFERING -> showBuffering(true)
                        Player.STATE_READY     -> { showBuffering(false); retryCount = 0 }
                        Player.STATE_ENDED     -> scheduleRetry()
                        Player.STATE_IDLE      -> {}
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    showBuffering(false)
                    scheduleRetry()
                }
            })
        }
    }

    private fun showBuffering(show: Boolean) {
        binding.progressBuffering.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun scheduleRetry() {
        if (retryCount >= maxRetries) {
            binding.tvStatus.visibility = View.VISIBLE
            binding.tvStatus.text       = "تعذّر الاتصال. حاول مجدداً."
            return
        }
        retryCount++
        binding.tvStatus.visibility = View.VISIBLE
        binding.tvStatus.text       = "إعادة الاتصال... ($retryCount/$maxRetries)"
        showBuffering(true)
        retryHandler.postDelayed({ initPlayer() }, retryDelayMs)
    }

    // Android TV remote control
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                player?.let { if (it.isPlaying) it.pause() else it.play() }
                true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                player?.let { it.seekTo(it.currentPosition + 10_000) }
                true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND,
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                player?.let { it.seekTo(maxOf(0, it.currentPosition - 10_000)) }
                true
            }
            KeyEvent.KEYCODE_VOLUME_UP -> {
                player?.let { it.volume = minOf(1f, it.volume + 0.1f) }
                true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                player?.let { it.volume = maxOf(0f, it.volume - 0.1f) }
                true
            }
            KeyEvent.KEYCODE_BACK -> { finish(); true }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onPause()   { super.onPause();   player?.pause() }
    override fun onResume()  { super.onResume();  player?.play()  }

    override fun onDestroy() {
        retryHandler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}

package com.lord.iptv.utils

import kotlinx.coroutines.*
import java.net.InetSocketAddress
import java.net.Socket

enum class ServerStatus { CONNECTED, WEAK, DISCONNECTED }

data class PingResult(val pingMs: Long, val status: ServerStatus)

object ServerMonitor {

    fun checkPing(host: String, port: Int): PingResult {
        return try {
            val start = System.currentTimeMillis()
            val socket = Socket()
            socket.connect(InetSocketAddress(host, port), 3000)
            val ping = System.currentTimeMillis() - start
            socket.close()
            val status = when {
                ping < 150  -> ServerStatus.CONNECTED
                ping < 500  -> ServerStatus.WEAK
                else        -> ServerStatus.WEAK
            }
            PingResult(ping, status)
        } catch (e: Exception) {
            PingResult(-1, ServerStatus.DISCONNECTED)
        }
    }

    fun startMonitoring(
        host: String,
        port: Int,
        intervalMs: Long = 5000L,
        scope: CoroutineScope,
        onResult: (PingResult) -> Unit
    ): Job {
        return scope.launch(Dispatchers.IO) {
            while (isActive) {
                val result = checkPing(host, port)
                withContext(Dispatchers.Main) { onResult(result) }
                delay(intervalMs)
            }
        }
    }
}

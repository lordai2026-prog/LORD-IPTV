package com.lord.iptv.data

data class Channel(
    val id: Int,
    val name: String,
    val url: String,
    val logoUrl: String,
    val group: String
)

object ChannelRepository {
    fun getChannels(): List<Channel> = listOf(
        Channel(1,  "Bein Sports 3 HD", "http://131.222.253.77:25461/live/lord/lord/1.m3u8",  "https://lord-homs.com/logos/BeIN Sports3.png",  "All"),
        Channel(2,  "Bein Sports 3 SD", "http://131.222.253.77:25461/live/lord/lord/2.m3u8",  "https://lord-homs.com/logos/BeIN Sports3.png",  "All"),
        Channel(3,  "Bein Sports 4 HD", "http://131.222.253.77:25461/live/lord/lord/3.m3u8",  "https://lord-homs.com/logos/BeIN Sports4.png",  "All"),
        Channel(4,  "Bein Sports 4 SD", "http://131.222.253.77:25461/live/lord/lord/4.m3u8",  "https://lord-homs.com/logos/BeIN Sports4.png",  "All"),
        Channel(5,  "Bein Sports 5 HD", "http://131.222.253.77:25461/live/lord/lord/5.m3u8",  "https://lord-homs.com/logos/BeIN Sports5.png",  "All"),
        Channel(6,  "Bein Sports 5 SD", "http://131.222.253.77:25461/live/lord/lord/6.m3u8",  "https://lord-homs.com/logos/BeIN Sports5.png",  "All"),
        Channel(7,  "Bein Sports 1 HD", "http://131.222.253.77:25461/live/lord/lord/7.m3u8",  "https://lord-homs.com/logos/Bein Sports 1 HD.png", "All"),
        Channel(8,  "Bein Sports 1 SD", "http://131.222.253.77:25461/live/lord/lord/8.m3u8",  "https://lord-homs.com/logos/Bein Sports 1 SD.png", "All"),
        Channel(9,  "Bein Sports 2 HD", "http://131.222.253.77:25461/live/lord/lord/9.m3u8",  "https://lord-homs.com/logos/Bein Sports 2 HD.png", "All"),
        Channel(10, "Bein Sports 2 SD", "http://131.222.253.77:25461/live/lord/lord/10.m3u8", "https://lord-homs.com/logos/Bein Sports 2 SD.png", "All"),
        Channel(11, "Bein MAX 1 HD",    "http://131.222.253.77:25461/live/lord/lord/11.m3u8", "https://lord-homs.com/logos/max1.png",             "All"),
        Channel(12, "Bein MAX 1 SD",    "http://131.222.253.77:25461/live/lord/lord/12.m3u8", "https://lord-homs.com/logos/max1.png",             "All"),
        Channel(13, "Bein MAX 2 HD",    "http://131.222.253.77:25461/live/lord/lord/13.m3u8", "https://lord-homs.com/logos/max2.png",             "All"),
        Channel(14, "Bein MAX 2 SD",    "http://131.222.253.77:25461/live/lord/lord/14.m3u8", "https://lord-homs.com/logos/max2.png",             "All")
    )

    val serverHost = "131.222.253.77"
    val serverPort = 25461
}

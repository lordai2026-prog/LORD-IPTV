package com.lord.iptv.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.RoundedCornersTransformation
import com.lord.iptv.R
import com.lord.iptv.data.Channel
import com.lord.iptv.databinding.ItemChannelBinding

class ChannelAdapter(
    private val channels: List<Channel>,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ViewHolder>() {

    private var focusedPosition = 0

    inner class ViewHolder(val binding: ItemChannelBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(channel: Channel, position: Int) {
            binding.tvChannelName.text   = channel.name
            binding.tvChannelNumber.text = "#${channel.id}"

            binding.ivLogo.load(channel.logoUrl) {
                crossfade(true)
                placeholder(R.drawable.ic_channel_placeholder)
                error(R.drawable.ic_channel_placeholder)
                transformations(RoundedCornersTransformation(8f))
            }

            binding.root.setOnClickListener { onClick(channel) }

            // TV D-pad focus
            binding.root.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    focusedPosition = position
                    binding.root.scaleX = 1.05f
                    binding.root.scaleY = 1.05f
                } else {
                    binding.root.scaleX = 1f
                    binding.root.scaleY = 1f
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemChannelBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(channels[position], position)
    }

    override fun getItemCount() = channels.size
}

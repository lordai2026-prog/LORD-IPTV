# ExoPlayer / Media3
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# OkHttp
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**

# Coil
-keep class coil.** { *; }

# App data classes
-keep class com.lord.iptv.data.** { *; }

# Kotlin
-keep class kotlin.** { *; }
-keepclassmembers class ** {
    @kotlin.jvm.JvmStatic *;
}
